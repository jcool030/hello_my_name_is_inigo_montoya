package com.example.dmitrykutin.delieverable1;

public class Admin {

    private String user;
    private String password;

    public Admin(String username, String password){

        this.user = username;
        this.password = password;

    }


}
