package com.example.dmitrykutin.delieverable1;

public class Contractor {

    private String user;
    private String password;

    public Contractor(String username, String password){

        this.user = username;
        this.password = password;

    }
}
